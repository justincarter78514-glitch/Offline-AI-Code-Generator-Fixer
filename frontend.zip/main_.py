"""
Offline AI Coding System - FastAPI Backend
==========================================
Architecture:
    HTML Frontend (index.html)
          |
    FastAPI Backend (this file)  <- uvicorn main:app --host 0.0.0.0 --port 8000
          |
    -------------------------
    |                       |
RAG (FAISS)            Ollama (native Windows)
    |                  Qwen + DeepSeek (dual routing)
LOCAL CODEBASE

HOW TO RUN:
    1. Install Ollama: https://ollama.com/download
    2. ollama pull qwen2.5-coder:7b
    3. ollama pull deepseek-coder:6.7b
    4. cd offline-coding-system/backend
    5. py -3.11 -m pip install -r requirements.txt
    6. py -3.11 -m uvicorn main:app --host 0.0.0.0 --port 8000
"""

import os
import re
import pickle
from typing import List

# Force HuggingFace to never contact the internet — use local cache only
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_DATASETS_OFFLINE"] = "1"
os.environ["HF_HUB_OFFLINE"] = "1"

import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import requests

# =========================================================
# Config — Ollama runs locally on Windows, no Linux needed
# =========================================================

OLLAMA_URL          = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434/api/generate")
QWEN_MODEL_NAME     = os.environ.get("QWEN_MODEL",     "qwen2.5-coder:3b")
DEEPSEEK_MODEL_NAME = os.environ.get("DEEPSEEK_MODEL", "deepseek-coder:1.3b")

RAG_INDEX_DIR  = os.path.join(os.path.dirname(__file__), "rag_index")
RAG_INDEX_FILE = os.path.join(RAG_INDEX_DIR, "faiss.index")
RAG_META_FILE  = os.path.join(RAG_INDEX_DIR, "meta.pkl")
os.makedirs(RAG_INDEX_DIR, exist_ok=True)

EMBED_MODEL_NAME = "all-MiniLM-L6-v2"
CHUNK_SIZE       = 80
CHUNK_OVERLAP    = 10
TOP_K            = 4

CODE_EXTENSIONS = {
    ".py",".js",".jsx",".ts",".tsx",".java",".c",".cpp",".h",".hpp",
    ".cs",".go",".rs",".php",".rb",".swift",".kt",".sql",".html",
    ".css",".sh",".json",".md",".yaml",".yml",
}

# =========================================================
# Static data
# =========================================================

LEVEL_PROMPTS = {
    "Beginner": "Explain everything in very simple terms. Use basic syntax, avoid advanced patterns, and add lots of comments explaining each line so a beginner programmer can learn from it.",
    "Junior":   "Write clean, working code with reasonable comments. Use standard best practices but keep solutions straightforward.",
    "Senior":   "Write production-quality code following best practices, proper error handling, and efficient patterns. Briefly explain key design decisions.",
    "Staff":    "Write highly optimized, scalable, and maintainable code. Consider edge cases, performance, architecture implications, and provide rationale for trade-offs.",
}

FRAMEWORKS = {
    "Python":     ["None","Django","Flask","FastAPI","PyTorch","TensorFlow","Pandas/NumPy"],
    "JavaScript": ["None","React","Vue","Node.js/Express","Next.js","Angular"],
    "TypeScript": ["None","React","Next.js","Angular","NestJS","Vue"],
    "Java":       ["None","Spring Boot","Hibernate","Android (SDK)","Maven/Gradle project"],
    "C":          ["None"],
    "C++":        ["None","Qt","Boost","Unreal Engine"],
    "C#":         ["None",".NET / ASP.NET Core","Unity","WPF"],
    "Go":         ["None","Gin","Echo","Fiber"],
    "Rust":       ["None","Actix","Axum","Rocket"],
    "PHP":        ["None","Laravel","Symfony","WordPress"],
    "Ruby":       ["None","Ruby on Rails","Sinatra"],
    "Swift":      ["None","SwiftUI","UIKit"],
    "Kotlin":     ["None","Android (Jetpack)","Ktor","Spring Boot"],
    "SQL":        ["None","PostgreSQL","MySQL","SQLite","SQL Server"],
    "HTML/CSS":   ["None","Tailwind CSS","Bootstrap"],
    "Bash":       ["None"],
}

POLITICAL_KEYWORDS = [
    "president","election","government","democrat","republican","political party",
    "parliament","communism","socialism","capitalism","dictator","regime",
    "prime minister","senate","congress","vote","campaign","geopolitics",
    "diplomacy","sanctions",
]

COUNTRY_NAMES = [
    "korea","south korea","north korea","united states","usa","america",
    "china","japan","russia","germany","france","united kingdom","uk",
    "india","canada","australia","brazil","mexico","italy","spain",
    "netherlands","sweden","norway","vietnam","thailand","philippines",
    "indonesia","pakistan","iran","iraq","israel","saudi arabia","turkey",
    "egypt","nigeria","south africa","argentina","ukraine","poland",
    "switzerland","belgium","austria","greece","portugal","denmark",
    "finland","ireland","new zealand","singapore","malaysia","taiwan",
    "hong kong","cuba","venezuela","colombia","chile","peru",
]

OFF_TOPIC_KEYWORDS = [
    "diagnosis","symptom","treatment","disease","patient","surgery",
    "medication","dosage","prescription","therapy","healthcare","hospital",
    "clinic","nurse","physician","mental health","cancer","vaccine",
    "anatomy","pharmacology","martial arts","karate","judo","taekwondo",
    "military","army","navy","air force","weapon","combat training",
    "self-defense","lawsuit","court","lawyer","attorney","legal advice",
    "contract law","litigation","criminal law","stock market",
    "investment portfolio","real estate","insurance policy",
    "manufacturing plant","supply chain logistics","agriculture","farming",
    "construction industry","oil and gas","recipe","cooking","diet plan",
    "workout routine","relationship advice","astrology","horoscope",
    "religion","theology",
]

PROGRAMMING_HINTS = [
    "code","function","bug","error","class","variable","script","algorithm",
    "api","compile","syntax","debug","refactor","loop","array","library",
    "framework","database","query","endpoint","component","module","import",
    "method","exception","test case",
]

ENGLISH_RE = re.compile(
    r"^[A-Za-z0-9\s.,;:!?'\"`()\[\]{}<>/\\|+\-=_*&^%$#@~\n\r\t]*$"
)

# =========================================================
# App
# =========================================================

app = FastAPI(title="Offline Coding System")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_embedder    = None
_faiss_index = None
_faiss_meta  = None


def get_embedder():
    global _embedder
    if _embedder is None:
        print("[RAG] Loading embedding model...", flush=True)
        # Force offline — never contact HuggingFace even if internet is available
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
        os.environ["HF_DATASETS_OFFLINE"] = "1"
        os.environ["HF_HUB_OFFLINE"] = "1"
        from sentence_transformers import SentenceTransformer
        _embedder = SentenceTransformer(EMBED_MODEL_NAME)
        print("[RAG] Embedding model ready.", flush=True)
    return _embedder


# =========================================================
# Content filters
# =========================================================

def is_english_only(text: str) -> bool:
    return bool(ENGLISH_RE.match(text))


def contains_korean(text: str) -> bool:
    return any(
        "\uac00" <= ch <= "\ud7a3" or
        "\u1100" <= ch <= "\u11ff" or
        "\u3130" <= ch <= "\u318f"
        for ch in text
    )


def find_blocked_terms(text: str) -> List[str]:
    found = []
    lower = text.lower()
    if not is_english_only(text):
        found.append("non-English characters detected — English only is allowed")
    if contains_korean(text):
        found.append("Korean language text")
    for kw in POLITICAL_KEYWORDS:
        if kw in lower:
            found.append(f"political term '{kw}'")
    for country in COUNTRY_NAMES:
        if country in lower:
            found.append(f"country name '{country}'")
    for term in OFF_TOPIC_KEYWORDS:
        if term in lower:
            found.append(f"unrelated topic '{term}'")
    return found


def is_programming_related(text: str) -> bool:
    if "```" in text:
        return True
    lower = text.lower()
    return any(hint in lower for hint in PROGRAMMING_HINTS)


# =========================================================
# RAG — FAISS indexing and retrieval
# =========================================================

def chunk_text(text: str, source: str):
    lines = text.splitlines()
    chunks = []
    i = 0
    while i < len(lines):
        chunk_lines = lines[i: i + CHUNK_SIZE]
        if chunk_lines:
            chunks.append({
                "source":     source,
                "start_line": i + 1,
                "end_line":   i + len(chunk_lines),
                "text":       "\n".join(chunk_lines),
            })
        i += CHUNK_SIZE - CHUNK_OVERLAP
    return chunks


def build_rag_index(project_path: str):
    import faiss
    embedder   = get_embedder()
    all_chunks = []

    SKIP_DIRS = {"node_modules",".git","__pycache__","venv",".venv","dist","build"}
    for root, dirs, files in os.walk(project_path):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in CODE_EXTENSIONS:
                continue
            fpath = os.path.join(root, fname)
            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
            except Exception:
                continue
            rel = os.path.relpath(fpath, project_path)
            all_chunks.extend(chunk_text(content, rel))

    if not all_chunks:
        return 0, 0

    texts      = [c["text"] for c in all_chunks]
    embeddings = embedder.encode(texts, convert_to_numpy=True, show_progress_bar=True).astype("float32")
    faiss.normalize_L2(embeddings)

    dim   = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)

    faiss.write_index(index, RAG_INDEX_FILE)
    with open(RAG_META_FILE, "wb") as f:
        pickle.dump({"project_path": project_path, "chunks": all_chunks}, f)

    global _faiss_index, _faiss_meta
    _faiss_index = index
    _faiss_meta  = {"project_path": project_path, "chunks": all_chunks}

    num_files = len({c["source"] for c in all_chunks})
    return num_files, len(all_chunks)


def _load_index():
    global _faiss_index, _faiss_meta
    if _faiss_index is not None:
        return
    if not os.path.isfile(RAG_INDEX_FILE) or not os.path.isfile(RAG_META_FILE):
        return
    import faiss
    _faiss_index = faiss.read_index(RAG_INDEX_FILE)
    with open(RAG_META_FILE, "rb") as f:
        _faiss_meta = pickle.load(f)


def retrieve_context(query: str, top_k: int = TOP_K):
    import faiss
    _load_index()
    if _faiss_index is None or _faiss_meta is None:
        return []
    embedder  = get_embedder()
    query_vec = embedder.encode([query], convert_to_numpy=True).astype("float32")
    faiss.normalize_L2(query_vec)

    scores, indices = _faiss_index.search(query_vec, top_k)
    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx == -1:
            continue
        chunk = _faiss_meta["chunks"][int(idx)]
        results.append({
            "source":     chunk["source"],
            "start_line": chunk["start_line"],
            "end_line":   chunk["end_line"],
            "text":       chunk["text"],
            "score":      float(score),
        })
    return results


def format_context_block(retrieved):
    if not retrieved:
        return ""
    parts = ["--- RELEVANT PROJECT CONTEXT (from your codebase via FAISS RAG) ---"]
    for r in retrieved:
        parts.append(
            f"\n# Source: {r['source']} "
            f"(lines {r['start_line']}-{r['end_line']}, score {r['score']:.2f})\n{r['text']}"
        )
    parts.append("\n--- END CONTEXT ---")
    parts.append(
        "Use the above only if relevant to the request. "
        "Stay consistent with existing code style and naming conventions."
    )
    return "\n".join(parts)


# =========================================================
# vLLM dual-model routing + judge/fixer pipeline
# =========================================================

def route_model(language: str) -> str:
    """Rule-based router: picks Qwen or DeepSeek based on language."""
    lang = (language or "").lower()
    if lang in ("c", "c++", "rust", "go", "sql"):
        return DEEPSEEK_MODEL_NAME
    return QWEN_MODEL_NAME


def call_ollama(model: str, prompt: str, timeout: int = 300):
    """Calls a local Ollama model. Returns (success, text)."""
    try:
        resp = requests.post(
            OLLAMA_URL,
            json={"model": model, "prompt": prompt, "stream": False},
            timeout=timeout,
            proxies={"http": None, "https": None},
        )
        resp.raise_for_status()
        text = resp.json().get("response", "").strip()
        if not text:
            return False, "Empty response from model"
        return True, text
    except requests.exceptions.ConnectionError:
        return False, (
            f"Cannot connect to Ollama at {OLLAMA_URL}. "
            "Is Ollama running? Check system tray or run: ollama serve"
        )
    except Exception as e:
        return False, str(e)


def build_full_prompt(system_prompt: str, user_prompt: str) -> str:
    return f"{system_prompt}\n\nUser request:\n{user_prompt}"


def run_pipeline(system_prompt: str, instructions: str, language: str, framework: str):
    trace = []

    # Step 1 — route
    primary_model = route_model(language)
    fallback_model = DEEPSEEK_MODEL_NAME if primary_model == QWEN_MODEL_NAME else QWEN_MODEL_NAME
    trace.append(f"Router -> {primary_model}")

    # Step 2 — primary model
    full_prompt = build_full_prompt(system_prompt, instructions)
    ok, draft = call_ollama(primary_model, full_prompt)
    used_model = primary_model

    # Step 3 — fallback if primary fails
    if not ok:
        trace.append(f"Primary failed ({draft}) -> fallback {fallback_model}")
        ok, draft = call_ollama(fallback_model, full_prompt)
        used_model = fallback_model

    if not ok:
        return {"output": None, "blocked": None,
                "error": f"All models failed. Last: {draft}", "trace": trace}
    trace.append(f"Draft by {used_model}")

    # Step 4 — judge/fixer pass
    judge_prompt = build_full_prompt(
        system_prompt,
        "You are a code reviewer and fixer (Judge AI). Review the draft below "
        "for bugs, syntax errors, missing imports, and logic issues. Return the "
        "corrected final version in the same format. If already correct, return unchanged.\n\n"
        f"--- DRAFT ---\n{draft}\n--- END DRAFT ---"
    )
    judge_ok, final = call_ollama(primary_model, judge_prompt)
    if judge_ok:
        trace.append(f"Judge/Fixer pass by {primary_model}")
    else:
        trace.append(f"Judge failed ({final}) -> using unreviewed draft")
        final = draft

    # Step 5 — output content filter
    violations = find_blocked_terms(final)
    if violations:
        return {"output": None, "blocked": violations, "error": None, "trace": trace}
    if not is_programming_related(final):
        return {"output": None, "blocked": ["response contained no programming content"],
                "error": None, "trace": trace}

    return {"output": final, "blocked": None, "error": None, "trace": trace}


# =========================================================
# Request models
# =========================================================

class GenerateRequest(BaseModel):
    level:        str  = "Beginner"
    language:     str  = "Python"
    framework:    str  = "None"
    instructions: str
    use_rag:      bool = True


class IndexRequest(BaseModel):
    project_path: str


# =========================================================
# Routes
# =========================================================

@app.get("/")
def root():
    return {"status": "ok", "service": "offline-coding-system-backend"}


@app.get("/meta")
def meta():
    return {"levels": list(LEVEL_PROMPTS.keys()), "frameworks": FRAMEWORKS}


@app.get("/rag_status")
def rag_status():
    _load_index()
    if _faiss_meta is None:
        return {"indexed": False}
    return {
        "indexed":      True,
        "project_path": _faiss_meta["project_path"],
        "num_chunks":   len(_faiss_meta["chunks"]),
    }


@app.post("/index_project")
def index_project(req: IndexRequest):
    path = req.project_path.strip()
    if not os.path.isdir(path):
        raise HTTPException(400, detail=f"Folder not found: {path}")
    try:
        num_files, num_chunks = build_rag_index(path)
    except ImportError:
        raise HTTPException(500, detail=(
            "Missing packages. Run:\n"
            "pip install faiss-cpu sentence-transformers"
        ))
    except Exception as e:
        raise HTTPException(500, detail=str(e))

    if num_chunks == 0:
        raise HTTPException(400, detail="No supported code/doc files found in that folder.")

    return {
        "message":    f"Indexed {num_files} file(s) into {num_chunks} chunk(s).",
        "num_files":  num_files,
        "num_chunks": num_chunks,
    }


@app.post("/generate")
def generate(req: GenerateRequest):
    instructions = req.instructions.strip()
    if not instructions:
        raise HTTPException(400, detail="No instructions provided.")

    # Input filter
    blocked = find_blocked_terms(instructions)
    if blocked:
        return {"blocked": blocked, "output": None, "pipeline": []}

    level = req.level if req.level in LEVEL_PROMPTS else "Beginner"
    fw_line = (
        f"Use the {req.framework} framework conventions where applicable.\n\n"
        if req.framework and req.framework != "None" else ""
    )
    system_prompt = (
        f"You are an AI coding assistant. {LEVEL_PROMPTS[level]}\n\n"
        f"Target language: {req.language}. {fw_line}"
        "Generate new code or fix issues in provided code. "
        "Return well-formatted code blocks with brief explanations. "
        "Stay strictly focused on programming topics. "
        "Respond in English only."
    )

    # RAG retrieval
    retrieved = []
    if req.use_rag:
        try:
            retrieved = retrieve_context(instructions)
        except Exception:
            pass
    if retrieved:
        system_prompt += "\n\n" + format_context_block(retrieved)

    result = run_pipeline(system_prompt, instructions, req.language, req.framework)

    trace = result.get("trace", [])
    if retrieved:
        rag_info = (
            f"RAG: {len(retrieved)} chunk(s) retrieved — "
            + ", ".join(f"{r['source']} ({r['score']:.2f})" for r in retrieved)
        )
        trace = [rag_info] + trace

    if result["error"]:
        return {"output": f"ERROR: {result['error']}", "pipeline": trace, "blocked": None}
    if result["blocked"]:
        return {"output": None, "blocked": result["blocked"], "pipeline": trace}

    return {"output": result["output"], "pipeline": trace, "blocked": None}