"""
Offline AI Code Generator — Full Pipeline
==========================================

Architecture:
    User
     ↓
    Intent Analyzer (Task + Language)
     ├── Task Analyzer     (generate / fix / review / explain / refactor)
     └── Language Analyzer (python / javascript / etc.)
     ↓
    AI Router
     ├── Qwen2.5-Coder 7B  → generate / explain / refactor
     └── DeepSeek-Coder 6.7B → fix / review
     ↓
    RAG Retriever (FAISS + Code Search)
     ↓
    Judge / Reviewer
     ↓
    Self Fix (Optional — if judge finds issues)
     ↓
    Final Answer

HOW TO RUN:
    1. Install Ollama: https://ollama.com/download
    2. Import models:
         ollama create qwen2.5-coder:7b   -f D:\\models\\Modelfile-qwen
         ollama create deepseek-coder:6.7b -f D:\\models\\Modelfile-deepseek
    3. cd offline-coding-system\\backend
    4. py -3.11 -m pip install -r requirements.txt
    5. py -3.11 -m uvicorn main:app --host 0.0.0.0 --port 8000
"""

import os
import re
import pickle
import json
from typing import List, Optional, Dict, Any

# Force HuggingFace offline — never contact the internet
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_DATASETS_OFFLINE"]  = "1"
os.environ["HF_HUB_OFFLINE"]       = "1"

import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import requests

# =========================================================
# Config
# =========================================================

OLLAMA_URL    = os.environ.get("OLLAMA_URL",    "http://127.0.0.1:11434/api/generate")
MODEL_QWEN    = os.environ.get("MODEL_QWEN",    "qwen2.5-coder:3b")    # generate / explain / refactor
MODEL_DEEPSEEK= os.environ.get("MODEL_DEEPSEEK","deepseek-coder:1.3b") # fix / review

RAG_INDEX_DIR  = os.path.join(os.path.dirname(__file__), "rag_index")
RAG_INDEX_FILE = os.path.join(RAG_INDEX_DIR, "faiss.index")
RAG_META_FILE  = os.path.join(RAG_INDEX_DIR, "meta.pkl")
os.makedirs(RAG_INDEX_DIR, exist_ok=True)

EMBED_MODEL   = "all-MiniLM-L6-v2"
CHUNK_SIZE    = 80
CHUNK_OVERLAP = 10
TOP_K         = 4

CODE_EXTENSIONS = {
    ".py",".js",".jsx",".ts",".tsx",".java",".c",".cpp",".h",".hpp",
    ".cs",".go",".rs",".php",".rb",".swift",".kt",".sql",".html",
    ".css",".sh",".json",".md",".yaml",".yml",
}

# =========================================================
# Static data
# =========================================================

LEVEL_PROMPTS = {
    "Beginner": "Use basic syntax, avoid advanced patterns, add lots of comments so a beginner can understand each line.",
    "Junior":   "Write clean, working code with reasonable comments. Use standard best practices.",
    "Senior":   "Write production-quality code with proper error handling. Briefly explain key design decisions.",
    "Staff":    "Write highly optimized, scalable, maintainable code. Explain architecture trade-offs.",
}

FRAMEWORKS = {
    "Python":     ["None","Django","Flask","FastAPI","PyTorch","TensorFlow","Pandas/NumPy"],
    "JavaScript": ["None","React","Vue","Node.js/Express","Next.js","Angular"],
    "TypeScript": ["None","React","Next.js","Angular","NestJS","Vue"],
    "Java":       ["None","Spring Boot","Hibernate","Android (SDK)","Maven/Gradle"],
    "C":          ["None"],
    "C++":        ["None","Qt","Boost","Unreal Engine"],
    "C#":         ["None",".NET / ASP.NET Core","Unity","WPF"],
    "Go":         ["None","Gin","Echo","Fiber"],
    "Rust":       ["None","Actix","Axum","Rocket"],
    "PHP":        ["None","Laravel","Symfony","WordPress"],
    "Ruby":       ["None","Ruby on Rails","Sinatra"],
    "Swift":      ["None","SwiftUI","UIKit"],
    "Kotlin":     ["None","Android (Jetpack)","Ktor","Spring Boot"],
    "SQL":        ["None","PostgreSQL","MySQL","SQLite","SQL Server"],
    "HTML/CSS":   ["None","Tailwind CSS","Bootstrap"],
    "Bash":       ["None"],
}

# =========================================================
# Intent Analyzer — Task Detection
# =========================================================

TASK_SIGNALS = {
    "fix": [
        "fix","bug","error","issue","broken","wrong","crash","fail",
        "not working","doesn't work","debug","exception","traceback",
        "undefined","null pointer","syntax error","repair","problem",
        "why does this","what is wrong",
    ],
    "review": [
        "review","check","inspect","look at","evaluate","assess",
        "is this correct","is this good","any issues","what do you think",
        "feedback","critique","code review",
    ],
    "refactor": [
        "refactor","clean up","cleanup","improve","optimize","restructure",
        "simplify","rewrite","reorganize","better way","more efficient",
        "best practice","make it cleaner",
    ],
    "explain": [
        "explain","what does","how does","describe","understand","clarify",
        "walk me through","what is","tell me about","how do i","why is",
    ],
    "generate": [
        "write","create","build","generate","make","implement","add","new",
        "develop","code","function","class","module","script","app",
    ],
}

LANGUAGE_PATTERNS = {
    "Python":     ["python","py","django","flask","fastapi","pytorch","pandas","numpy","pip"],
    "JavaScript": ["javascript","js","react","vue","angular","node","express","next","npm"],
    "TypeScript": ["typescript","ts","tsx","nestjs"],
    "Java":       ["java","spring","maven","gradle","android"],
    "C":          ["c code"," in c","c program","c language"],
    "C++":        ["c++","cpp","qt","boost","unreal"],
    "C#":         ["c#","csharp","dotnet",".net","unity","wpf","asp.net"],
    "Go":         ["golang","go code","gin","fiber","echo"],
    "Rust":       ["rust","cargo","actix","axum","rocket"],
    "PHP":        ["php","laravel","symfony","wordpress"],
    "Ruby":       ["ruby","rails","sinatra","gem"],
    "Swift":      ["swift","swiftui","uikit","xcode","ios"],
    "Kotlin":     ["kotlin","ktor","jetpack","android kotlin"],
    "SQL":        ["sql","postgresql","mysql","sqlite","select","insert","update","delete","query"],
    "Bash":       ["bash","shell","sh script","linux command","terminal","cli"],
    "HTML/CSS":   ["html","css","tailwind","bootstrap","webpage","frontend","web page"],
}


def analyze_task(instructions: str) -> str:
    """Task Analyzer: returns one of generate / fix / review / refactor / explain."""
    lower = instructions.lower()
    scores = {task: 0 for task in TASK_SIGNALS}
    for task, signals in TASK_SIGNALS.items():
        for signal in signals:
            if signal in lower:
                scores[task] += 1
    # If code block pasted without strong signals → likely fix
    if "```" in instructions and scores["fix"] == 0 and scores["review"] == 0:
        scores["fix"] += 1
    best = max(scores, key=lambda t: scores[t])
    return best if scores[best] > 0 else "generate"


def analyze_language(instructions: str, selected_language: str) -> str:
    """Language Analyzer: confirms or overrides the UI-selected language
    based on keywords found in the instruction text."""
    lower = instructions.lower()
    for lang, patterns in LANGUAGE_PATTERNS.items():
        for pat in patterns:
            if pat in lower:
                return lang
    return selected_language  # fall back to what the user selected in the UI


def route_model(task: str, language: str) -> tuple:
    """AI Router: picks the best model based on task + language.
    Returns (primary_model, fallback_model)."""
    fix_review_tasks = {"fix", "review"}
    systems_langs    = {"C", "C++", "Rust", "Go", "SQL"}

    if task in fix_review_tasks or language in systems_langs:
        return MODEL_DEEPSEEK, MODEL_QWEN
    return MODEL_QWEN, MODEL_DEEPSEEK


# =========================================================
# Content filters
# =========================================================

POLITICAL_KEYWORDS = [
    "president","election","government","democrat","republican","political party",
    "parliament","communism","socialism","capitalism","dictator","regime",
    "prime minister","senate","congress","vote","campaign","geopolitics",
    "diplomacy","sanctions",
]
COUNTRY_NAMES = [
    "korea","south korea","north korea","united states","usa","america",
    "china","japan","russia","germany","france","united kingdom","uk",
    "india","canada","australia","brazil","mexico","italy","spain",
    "netherlands","sweden","norway","vietnam","thailand","philippines",
    "indonesia","pakistan","iran","iraq","israel","saudi arabia","turkey",
    "egypt","nigeria","south africa","argentina","ukraine","poland",
    "switzerland","belgium","austria","greece","portugal","denmark",
    "finland","ireland","new zealand","singapore","malaysia","taiwan",
    "hong kong","cuba","venezuela","colombia","chile","peru",
]
OFF_TOPIC_KEYWORDS = [
    "diagnosis","symptom","treatment","disease","patient","surgery","medication",
    "dosage","prescription","therapy","healthcare","hospital","clinic","nurse",
    "physician","mental health","cancer","vaccine","anatomy","pharmacology",
    "martial arts","karate","judo","taekwondo","military","army","navy",
    "air force","weapon","combat","self-defense","lawsuit","court","lawyer",
    "attorney","legal advice","contract law","litigation","criminal law",
    "stock market","investment portfolio","real estate","insurance policy",
    "supply chain logistics","agriculture","farming","oil and gas",
    "recipe","cooking","diet plan","workout routine","relationship advice",
    "astrology","horoscope","religion","theology",
]
PROGRAMMING_HINTS = [
    "code","function","bug","error","class","variable","script","algorithm",
    "api","compile","syntax","debug","refactor","loop","array","library",
    "framework","database","query","endpoint","component","module","import",
    "method","exception","test","return","def ","const ","let ","var ",
]
ENGLISH_RE = re.compile(
    r"^[A-Za-z0-9\s.,;:!?'\"`()\[\]{}<>/\\|+\-=_*&^%$#@~\n\r\t]*$"
)


def is_english_only(text: str) -> bool:
    return bool(ENGLISH_RE.match(text))


def contains_korean(text: str) -> bool:
    return any(
        "\uac00" <= ch <= "\ud7a3" or
        "\u1100" <= ch <= "\u11ff" or
        "\u3130" <= ch <= "\u318f"
        for ch in text
    )


def find_blocked_terms(text: str) -> List[str]:
    found = []
    lower = text.lower()
    if not is_english_only(text):
        found.append("non-English characters — English only is allowed")
    if contains_korean(text):
        found.append("Korean language text")
    for kw in POLITICAL_KEYWORDS:
        if kw in lower:
            found.append(f"political term '{kw}'")
    for c in COUNTRY_NAMES:
        if c in lower:
            found.append(f"country name '{c}'")
    for t in OFF_TOPIC_KEYWORDS:
        if t in lower:
            found.append(f"unrelated topic '{t}'")
    return found


def is_programming_related(text: str) -> bool:
    if "```" in text:
        return True
    lower = text.lower()
    return any(h in lower for h in PROGRAMMING_HINTS)


# =========================================================
# RAG Retriever — FAISS + Code Search
# =========================================================

_embedder    = None
_faiss_index = None
_faiss_meta  = None


def get_embedder():
    global _embedder
    if _embedder is None:
        print("[RAG] Loading embedding model from local cache...", flush=True)
        from sentence_transformers import SentenceTransformer
        _embedder = SentenceTransformer(EMBED_MODEL)
        print("[RAG] Embedding model ready.", flush=True)
    return _embedder


def chunk_text(text: str, source: str):
    lines = text.splitlines()
    chunks, i = [], 0
    while i < len(lines):
        chunk_lines = lines[i: i + CHUNK_SIZE]
        if chunk_lines:
            chunks.append({
                "source":     source,
                "start_line": i + 1,
                "end_line":   i + len(chunk_lines),
                "text":       "\n".join(chunk_lines),
            })
        i += CHUNK_SIZE - CHUNK_OVERLAP
    return chunks


def build_rag_index(project_path: str):
    import faiss
    embedder, all_chunks = get_embedder(), []
    SKIP = {"node_modules",".git","__pycache__","venv",".venv","dist","build"}

    for root, dirs, files in os.walk(project_path):
        dirs[:] = [d for d in dirs if d not in SKIP]
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in CODE_EXTENSIONS:
                continue
            fpath = os.path.join(root, fname)
            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
            except Exception:
                continue
            all_chunks.extend(chunk_text(content, os.path.relpath(fpath, project_path)))

    if not all_chunks:
        return 0, 0

    texts      = [c["text"] for c in all_chunks]
    embeddings = embedder.encode(texts, convert_to_numpy=True, show_progress_bar=True).astype("float32")
    faiss.normalize_L2(embeddings)

    index = faiss.IndexFlatIP(embeddings.shape[1])
    index.add(embeddings)
    faiss.write_index(index, RAG_INDEX_FILE)
    with open(RAG_META_FILE, "wb") as f:
        pickle.dump({"project_path": project_path, "chunks": all_chunks}, f)

    global _faiss_index, _faiss_meta
    _faiss_index, _faiss_meta = index, {"project_path": project_path, "chunks": all_chunks}
    return len({c["source"] for c in all_chunks}), len(all_chunks)


def _load_index():
    global _faiss_index, _faiss_meta
    if _faiss_index is not None:
        return
    if not os.path.isfile(RAG_INDEX_FILE) or not os.path.isfile(RAG_META_FILE):
        return
    import faiss
    _faiss_index = faiss.read_index(RAG_INDEX_FILE)
    with open(RAG_META_FILE, "rb") as f:
        _faiss_meta = pickle.load(f)


def retrieve_context(query: str, top_k: int = TOP_K) -> List[Dict]:
    """RAG Retriever: FAISS semantic search + keyword code search combined."""
    import faiss
    _load_index()
    if _faiss_index is None or _faiss_meta is None:
        return []

    embedder  = get_embedder()
    query_vec = embedder.encode([query], convert_to_numpy=True).astype("float32")
    faiss.normalize_L2(query_vec)

    scores, indices = _faiss_index.search(query_vec, top_k)
    results = []
    seen_sources = set()

    for score, idx in zip(scores[0], indices[0]):
        if idx == -1:
            continue
        chunk = _faiss_meta["chunks"][int(idx)]
        results.append({
            "source":     chunk["source"],
            "start_line": chunk["start_line"],
            "end_line":   chunk["end_line"],
            "text":       chunk["text"],
            "score":      float(score),
            "method":     "faiss",
        })
        seen_sources.add(chunk["source"])

    # Code search: keyword scan for function/class names mentioned in the query
    keywords = [w for w in re.findall(r'\b\w+\b', query) if len(w) > 3]
    for chunk in _faiss_meta["chunks"]:
        if chunk["source"] in seen_sources:
            continue
        text_lower = chunk["text"].lower()
        if any(kw.lower() in text_lower for kw in keywords):
            results.append({
                "source":     chunk["source"],
                "start_line": chunk["start_line"],
                "end_line":   chunk["end_line"],
                "text":       chunk["text"],
                "score":      0.5,
                "method":     "code_search",
            })
            seen_sources.add(chunk["source"])
            if len(results) >= top_k + 2:
                break

    return results


def format_context_block(retrieved: List[Dict]) -> str:
    if not retrieved:
        return ""
    parts = ["--- RAG CONTEXT (FAISS + Code Search from your codebase) ---"]
    for r in retrieved:
        parts.append(
            f"\n# [{r['method']}] {r['source']} "
            f"(lines {r['start_line']}-{r['end_line']}, score {r['score']:.2f})\n{r['text']}"
        )
    parts.append("\n--- END RAG CONTEXT ---")
    parts.append(
        "Use the above context to stay consistent with existing code style and naming. "
        "Only apply it if relevant to the request."
    )
    return "\n".join(parts)


# =========================================================
# Ollama call
# =========================================================

def call_ollama(model: str, prompt: str, timeout: int = 300):
    try:
        resp = requests.post(
            OLLAMA_URL,
            json={"model": model, "prompt": prompt, "stream": False},
            timeout=timeout,
            proxies={"http": None, "https": None},
        )
        resp.raise_for_status()
        text = resp.json().get("response", "").strip()
        if not text:
            return False, "Empty response"
        return True, text
    except requests.exceptions.ConnectionError:
        return False, (
            f"Cannot connect to Ollama at {OLLAMA_URL}. "
            "Is Ollama running? Check system tray or run: ollama serve"
        )
    except Exception as e:
        return False, str(e)


# =========================================================
# Full pipeline matching the architecture diagram
# =========================================================

def build_system_prompt(task: str, language: str, framework: str, level: str) -> str:
    fw_line = (
        f"Use the {framework} framework conventions.\n\n"
        if framework and framework != "None" else ""
    )
    task_instructions = {
        "generate":  "Generate complete, working code based on the user request. Include a brief explanation.",
        "fix":       "Find and fix all bugs in the provided code. Explain what was wrong and show the corrected version.",
        "review":    "Review the provided code. List issues found (bugs, style, performance, security) and suggest improvements.",
        "refactor":  "Refactor the provided code for better readability, maintainability, and performance. Explain changes made.",
        "explain":   "Explain the provided code or concept clearly. Use examples where helpful.",
    }
    return (
        f"You are an expert AI coding assistant. {LEVEL_PROMPTS.get(level, LEVEL_PROMPTS['Senior'])}\n\n"
        f"Target language: {language}. {fw_line}"
        f"{task_instructions.get(task, task_instructions['generate'])} "
        "Respond in English only. Stay strictly focused on programming topics."
    )


def run_pipeline(
    instructions: str,
    language: str,
    framework: str,
    level: str,
    use_rag: bool,
    task_override: Optional[str],
) -> Dict[str, Any]:

    pipeline_trace = []
    pipeline_trace.append("=== PIPELINE START ===")

    # ── Step 1: Intent Analyzer ───────────────────────────
    task     = task_override if task_override in TASK_SIGNALS else analyze_task(instructions)
    det_lang = analyze_language(instructions, language)
    pipeline_trace.append(f"[Intent Analyzer] Task: {task} | Language: {det_lang}")

    # ── Step 2: AI Router ─────────────────────────────────
    primary_model, fallback_model = route_model(task, det_lang)
    pipeline_trace.append(f"[AI Router] Primary: {primary_model} | Fallback: {fallback_model}")

    # ── Step 3: RAG Retriever (FAISS + Code Search) ───────
    retrieved = []
    if use_rag:
        try:
            retrieved = retrieve_context(instructions)
            if retrieved:
                faiss_hits  = [r for r in retrieved if r["method"] == "faiss"]
                code_hits   = [r for r in retrieved if r["method"] == "code_search"]
                pipeline_trace.append(
                    f"[RAG Retriever] {len(retrieved)} chunk(s) retrieved — "
                    f"{len(faiss_hits)} FAISS, {len(code_hits)} code search | "
                    + ", ".join(f"{r['source']} ({r['score']:.2f})" for r in retrieved)
                )
            else:
                pipeline_trace.append("[RAG Retriever] No index found or no relevant chunks")
        except Exception as e:
            pipeline_trace.append(f"[RAG Retriever] Skipped: {e}")

    # ── Step 4: Build prompt with RAG context ─────────────
    system_prompt = build_system_prompt(task, det_lang, framework, level)
    if retrieved:
        system_prompt += "\n\n" + format_context_block(retrieved)
    full_prompt = f"{system_prompt}\n\nUser request:\n{instructions}"

    # ── Step 5: Primary model call ────────────────────────
    ok, draft = call_ollama(primary_model, full_prompt)
    if not ok:
        pipeline_trace.append(f"[Model Call] {primary_model} failed: {draft} -> trying fallback")
        ok, draft = call_ollama(fallback_model, full_prompt)
        if not ok:
            return {
                "output": None, "blocked": None,
                "error": f"All models failed: {draft}",
                "trace": pipeline_trace, "task": task, "language": det_lang,
            }
        pipeline_trace.append(f"[Model Call] Draft by fallback: {fallback_model}")
    else:
        pipeline_trace.append(f"[Model Call] Draft by primary: {primary_model}")

    # ── Step 6: Judge / Reviewer ──────────────────────────
    judge_prompt = (
        f"{system_prompt}\n\n"
        "You are now the Judge/Reviewer. Carefully evaluate the draft below:\n"
        "1. Check for bugs, syntax errors, missing imports, logic errors.\n"
        "2. Check consistency with any RAG context provided.\n"
        "3. Rate quality: PASS or NEEDS_FIX\n"
        "4. If NEEDS_FIX, describe exactly what needs to change.\n\n"
        f"--- DRAFT ---\n{draft}\n--- END DRAFT ---\n\n"
        "Respond in this exact format:\n"
        "VERDICT: PASS or NEEDS_FIX\n"
        "ISSUES: (list issues if NEEDS_FIX, else 'None')\n"
        "DRAFT: (copy the full draft here unchanged)"
    )
    # Use the OTHER model as judge for independent review
    judge_model = fallback_model if primary_model == MODEL_QWEN else MODEL_QWEN
    judge_ok, judge_output = call_ollama(judge_model, judge_prompt)

    needs_fix = False
    issues    = ""
    if judge_ok:
        verdict_match = re.search(r"VERDICT:\s*(PASS|NEEDS_FIX)", judge_output, re.IGNORECASE)
        issues_match  = re.search(r"ISSUES:\s*(.+?)(?=DRAFT:|$)", judge_output, re.IGNORECASE | re.DOTALL)
        verdict  = verdict_match.group(1).upper() if verdict_match else "PASS"
        issues   = issues_match.group(1).strip() if issues_match else ""
        needs_fix= verdict == "NEEDS_FIX" and issues and issues.lower() != "none"
        pipeline_trace.append(
            f"[Judge/Reviewer] Model: {judge_model} | Verdict: {verdict}"
            + (f" | Issues: {issues[:120]}..." if needs_fix and len(issues) > 120 else f" | Issues: {issues}" if needs_fix else "")
        )
    else:
        pipeline_trace.append(f"[Judge/Reviewer] Skipped: {judge_output}")

    # ── Step 7: Self Fix (optional — only if judge flagged issues) ────────
    final = draft
    if needs_fix:
        fix_prompt = (
            f"{system_prompt}\n\n"
            "The Judge/Reviewer found the following issues in the code draft below. "
            "Fix ALL of them and return the complete corrected code with a brief explanation.\n\n"
            f"ISSUES TO FIX:\n{issues}\n\n"
            f"--- DRAFT TO FIX ---\n{draft}\n--- END DRAFT ---"
        )
        fix_ok, fixed = call_ollama(primary_model, fix_prompt)
        if fix_ok:
            final = fixed
            pipeline_trace.append(f"[Self Fix] Applied by {primary_model}")
        else:
            pipeline_trace.append(f"[Self Fix] Failed ({fixed}) -> using original draft")
    else:
        pipeline_trace.append("[Self Fix] Not needed — draft passed review")

    pipeline_trace.append("=== PIPELINE END ===")

    # ── Step 8: Output content filter ─────────────────────
    violations = find_blocked_terms(final)
    if violations:
        return {"output": None, "blocked": violations, "error": None,
                "trace": pipeline_trace, "task": task, "language": det_lang}
    if not is_programming_related(final):
        return {"output": None, "blocked": ["response contained no programming content"],
                "error": None, "trace": pipeline_trace, "task": task, "language": det_lang}

    return {"output": final, "blocked": None, "error": None,
            "trace": pipeline_trace, "task": task, "language": det_lang}


# =========================================================
# FastAPI app
# =========================================================

app = FastAPI(title="Offline AI Code Generator")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class GenerateRequest(BaseModel):
    level:        str           = "Senior"
    language:     str           = "Python"
    framework:    str           = "None"
    instructions: str
    use_rag:      bool          = True
    task:         Optional[str] = None


class IndexRequest(BaseModel):
    project_path: str


@app.get("/")
def root():
    return {"status": "ok", "service": "offline-ai-code-generator"}


@app.get("/meta")
def meta():
    return {
        "levels":    list(LEVEL_PROMPTS.keys()),
        "frameworks": FRAMEWORKS,
        "models":    {"qwen": MODEL_QWEN, "deepseek": MODEL_DEEPSEEK},
        "tasks":     list(TASK_SIGNALS.keys()),
    }


@app.get("/rag_status")
def rag_status():
    _load_index()
    if _faiss_meta is None:
        return {"indexed": False}
    return {"indexed": True, "project_path": _faiss_meta["project_path"],
            "num_chunks": len(_faiss_meta["chunks"])}


@app.post("/index_project")
def index_project(req: IndexRequest):
    path = req.project_path.strip()
    if not os.path.isdir(path):
        raise HTTPException(400, detail=f"Folder not found: {path}")
    try:
        num_files, num_chunks = build_rag_index(path)
    except ImportError:
        raise HTTPException(500, detail="Run: py -3.11 -m pip install faiss-cpu sentence-transformers")
    except Exception as e:
        raise HTTPException(500, detail=str(e))
    if num_chunks == 0:
        raise HTTPException(400, detail="No supported code/doc files found.")
    return {"message": f"Indexed {num_files} file(s) into {num_chunks} chunk(s).",
            "num_files": num_files, "num_chunks": num_chunks}


@app.post("/generate")
def generate(req: GenerateRequest):
    instructions = req.instructions.strip()
    if not instructions:
        raise HTTPException(400, detail="No instructions provided.")

    blocked = find_blocked_terms(instructions)
    if blocked:
        return {"blocked": blocked, "output": None, "pipeline": [], "task": None, "language": None}

    result = run_pipeline(
        instructions  = instructions,
        language      = req.language,
        framework     = req.framework,
        level         = req.level if req.level in LEVEL_PROMPTS else "Senior",
        use_rag       = req.use_rag,
        task_override = req.task,
    )

    if result["error"]:
        return {"output": f"ERROR: {result['error']}", "pipeline": result["trace"],
                "blocked": None, "task": result["task"], "language": result["language"]}
    if result["blocked"]:
        return {"output": None, "blocked": result["blocked"], "pipeline": result["trace"],
                "task": result["task"], "language": result["language"]}

    return {"output": result["output"], "pipeline": result["trace"],
            "blocked": None, "task": result["task"], "language": result["language"]}
